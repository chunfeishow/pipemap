/*模块初始化配置*/
var Project_Paths = {
    'module': 'module/nav/script'
};

var Project_Shim = {}

var require = {
    baseUrl: '../../',
    config: {
        moduleurl: ".",
        jsname: "module/controller"
    }
};